import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from statsmodels.tsa.arima.model import ARIMA
from statsmodels.tsa.holtwinters import ExponentialSmoothing
from prophet import Prophet
import warnings

warnings.filterwarnings("ignore")

# ==========================================================
# 📈 Forecast pomocí ARIMA
# ==========================================================
def forecast_arima(history, periods=30):
    """
    Forecast ceny pomocí ARIMA – trénuje se jen na posledním roce dat.
    """
    close_prices = history['Close'].dropna()
    last_year = close_prices.last('365D')  # ✅ jen poslední rok dat
    model = ARIMA(last_year, order=(1,1,1))  # jednodušší ARIMA s diferenciací
    model_fit = model.fit()
    forecast = model_fit.forecast(steps=periods)
    return forecast

# ==========================================================
# 🔮 Forecast pomocí Prophet
# ==========================================================
def forecast_prophet(history, periods=30):
    """
    Forecast ceny pomocí Prophet (jen poslední rok dat, minimalizace trendového biasu).
    """
    # ✅ připravíme dataframe
    df = history.reset_index()[['Date', 'Close']].rename(columns={'Date': 'ds', 'Close': 'y'})
    df['ds'] = pd.to_datetime(df['ds']).dt.tz_localize(None)

    # ✅ použijeme jen poslední rok dat
    last_year_start = df['ds'].max() - pd.DateOffset(years=1)
    df_last_year = df[df['ds'] >= last_year_start]

    # ✅ Prophet konfigurace (žádná sezónnost, menší citlivost na trend)
    model = Prophet(
        daily_seasonality=True,
        yearly_seasonality=False,
        weekly_seasonality=False,
        changepoint_prior_scale=0.05
    )
    model.fit(df_last_year)

    # ✅ vytvoříme budoucí dataframe
    future = model.make_future_dataframe(periods=periods)
    forecast = model.predict(future)

    # ✅ posuneme forecast, aby začínal na poslední closing price
    last_close = df_last_year['y'].iloc[-1]
    prophet_last_known = forecast.loc[forecast['ds'] == df_last_year['ds'].iloc[-1], 'yhat'].values[0]
    offset = last_close - prophet_last_known
    forecast['yhat'] = forecast['yhat'] + offset

    return forecast

# ==========================================================
# 📉 Forecast pomocí Holt-Winters
# ==========================================================
def forecast_holt_winters(history, periods=30):
    """
    Forecast pomocí Holt-Winters – trénuje se jen na posledním roce dat.
    """
    close_prices = history['Close'].dropna()
    last_year = close_prices.last('365D')  # ✅ jen poslední rok dat
    model = ExponentialSmoothing(last_year, trend="add", seasonal=None)
    model_fit = model.fit()
    forecast = model_fit.forecast(steps=periods)
    return forecast

# ==========================================================
# 🎲 Monte Carlo simulace
# ==========================================================
def monte_carlo_simulation(history, simulations=100, days=30):
    """
    Monte Carlo simulace pro predikci cen (generuje 100 simulovaných drah).
    Vrací pouze predikované hodnoty (bez startovní ceny).
    """
    close_prices = history['Close']
    returns = close_prices.pct_change().dropna()
    last_price = close_prices.iloc[-1]

    forecast_paths = []
    for _ in range(simulations):
        simulated_prices = [last_price]
        for _ in range(days):
            simulated_prices.append(simulated_prices[-1] * (1 + np.random.choice(returns)))
        # ➡️ odstraníme první hodnotu (startovní cena)
        forecast_paths.append(simulated_prices[1:])
    return np.array(forecast_paths)

# ==========================================================
# 📊 Plot forecastů
# ==========================================================
def plot_forecast(history, arima_forecast, prophet_forecast, holt_forecast, days=30):
    """
    Vykreslí graf historických cen + forecastů z ARIMA, Prophet a Holt-Winters.
    ➡️ Zobrazuje pouze poslední rok historie + forecast.
    ➡️ Prophet zobrazuje jen predikované hodnoty (stejný horizont jako ARIMA a Holt-Winters).
    """
    # 🟢 zrušíme timezone, aby nevznikal konflikt při porovnávání dat
    history = history.copy()
    history.index = history.index.tz_localize(None)

    prophet_forecast = prophet_forecast.copy()
    prophet_forecast['ds'] = prophet_forecast['ds'].dt.tz_localize(None)

    # 🟢 vybereme jen poslední rok historie
    last_year = history.last('365D')

    plt.figure(figsize=(12,6))

    # 🟢 vykreslíme poslední rok historie
    plt.plot(last_year.index, last_year['Close'], label='Historie (poslední rok)', color='black')

    # 📆 datumy pro forecast
    future_dates = pd.date_range(start=history.index[-1], periods=days+1, freq='B')[1:]

    # 🔵 ARIMA forecast
    plt.plot(future_dates, arima_forecast, label='ARIMA', linestyle='--', color='blue')

    # 🟢 Prophet forecast – jen budoucí období
    prophet_future = prophet_forecast[prophet_forecast['ds'] > history.index[-1]]
    prophet_future = prophet_future.head(days)  # jistota, že vezme jen daný počet dní
    plt.plot(prophet_future['ds'], prophet_future['yhat'], label='Prophet', linestyle='--', color='green')

    # 🟠 Holt-Winters forecast
    plt.plot(future_dates, holt_forecast, label='Holt-Winters', linestyle='--', color='orange')

    # 🎨 úprava grafu
    plt.title("📈 Forecast ceny akcie (ARIMA, Prophet & Holt-Winters)")
    plt.xlabel("Datum")
    plt.ylabel("Cena (USD)")
    plt.grid(True)
    plt.legend()
    plt.show()

def plot_monte_carlo(history, mc_simulation, days=30):
    """
    Vykreslí Monte Carlo simulaci cen akcie.
    ➡️ Zobrazuje pouze poslední rok historie + simulace na X dní dopředu.
    """
    # 🟢 Zrušíme timezone
    history = history.copy()
    history.index = history.index.tz_localize(None)

    # 🟢 Vybereme jen poslední rok historie
    last_year = history.last('365D')

    # 📆 datumy pro forecast
    future_dates = pd.date_range(start=history.index[-1], periods=days+1, freq='B')[1:]

    plt.figure(figsize=(12, 6))

    # 🟢 vykreslíme poslední rok historie
    plt.plot(last_year.index, last_year['Close'], color='black', label='Historie (poslední rok)')

    # 🔄 vykreslíme Monte Carlo simulace
    for i in range(mc_simulation.shape[0]):
        plt.plot(future_dates, mc_simulation[i], color='gray', alpha=0.1)

    # 🎨 úprava grafu
    plt.title("📈 Monte Carlo simulace cen akcie")
    plt.xlabel("Datum")
    plt.ylabel("Cena (USD)")
    plt.grid(True)
    plt.legend()
    plt.show()

def evaluate_forecast(arima_forecast):
    """
    Shrnutí forecastu – pokud průměr roste, označíme bullish.
    """
    start_price = arima_forecast.iloc[0]
    end_price = arima_forecast.iloc[-1]
    if end_price > start_price * 1.03:
        return "🚀 Forecast ukazuje růstový trend."
    elif end_price < start_price * 0.97:
        return "📉 Forecast ukazuje poklesový trend."
    else:
        return "⚖️ Forecast naznačuje spíše stabilní vývoj."
